@echo off
rem Single player co-op: the RealRTCW campaign with friends, with all the single player cutscenes and controls.
rem Start a NEW GAME; Steam friends join with "SP co-op join" or Join Game in Steam.
call "%~dp0RealRTCW VR.bat" +set g_spCoop 1 %*
