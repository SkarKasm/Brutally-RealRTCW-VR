@echo off
rem RealRTCW-VR: The Dark Army: Uprising on the monitor only (a headset is ignored).
call "%~dp0game\find_tda.cmd" || exit /b 1
call "%~dp0RealRTCW VR.bat" +set fs_game TDA +set vr_enable 0 %*
