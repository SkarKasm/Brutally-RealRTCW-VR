@echo off
rem Single player co-op on the monitor: joins the Steam friend who is hosting.
call "%~dp0RealRTCW VR.bat" +set g_spCoop 1 +set vr_enable 0 +steamjoin %*
