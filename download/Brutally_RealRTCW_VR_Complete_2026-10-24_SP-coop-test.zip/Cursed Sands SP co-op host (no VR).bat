@echo off
rem Single player co-op on the monitor: the Cursed Sands campaign with friends.
call "%~dp0RealRTCW VR.bat" +set fs_game EE +set g_spCoop 1 +set vr_enable 0 %*
