@echo off
rem RealRTCW-VR co-op: the original campaign in co-op, in VR
rem   Classic co-op VR.bat                 main menu (CREATE SERVER to host, JOIN GAME to join)
rem   Classic co-op VR.bat +connect <ip>   join a friend's game directly
call "%~dp0game\find_coop.cmd" || exit /b 1
cd /d "%~dp0game"
start "" RTCWCoop.x64.exe +set fs_basepath "%COOP%" +set fs_homepath "%~dp0game" +set fs_game "" %*
