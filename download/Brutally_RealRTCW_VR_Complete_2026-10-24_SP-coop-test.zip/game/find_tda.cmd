@echo off
rem Finds The Dark Army: Uprising, RealRTCW's Steam Workshop item 2253494213, and links it into
rem RealRTCW as its TDA folder, where the game looks for fs_game TDA (the link is a folder
rem junction: nothing is copied or changed in the Workshop folder). Set TDAWS yourself before
rem calling this to use another location.
call "%~dp0find_realrtcw.cmd" || exit /b 1
if exist "%RRTCW%\TDA\tda.pk3" goto :eof
if not defined TDAWS set "TDAWS=%RRTCW%\..\..\workshop\content\1379630\2253494213"
for %%D in ("%TDAWS%") do set "TDAWS=%%~fD"
if not exist "%TDAWS%\tda.pk3" (
  echo Could not find The Dark Army: Uprising. Subscribe to it on RealRTCW's Steam Workshop
  echo page and let Steam download it, or edit game\find_tda.cmd and set TDAWS to the folder
  echo that holds its tda.pk3.
  pause
  exit /b 1
)
rem an empty TDA folder in the way goes (rmdir only removes empty folders)
if exist "%RRTCW%\TDA" rmdir "%RRTCW%\TDA" 2>nul
mklink /J "%RRTCW%\TDA" "%TDAWS%" >nul
if not exist "%RRTCW%\TDA\tda.pk3" (
  echo Could not link "%TDAWS%" in as "%RRTCW%\TDA".
  pause
  exit /b 1
)
