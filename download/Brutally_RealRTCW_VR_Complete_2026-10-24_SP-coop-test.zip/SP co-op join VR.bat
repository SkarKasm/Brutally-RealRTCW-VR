@echo off
rem Single player co-op: joins the Steam friend who is hosting (any campaign, the game switches to theirs).
call "%~dp0RealRTCW VR.bat" +set g_spCoop 1 +steamjoin %*
