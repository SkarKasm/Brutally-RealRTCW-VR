@echo off
rem RealRTCW-VR: The Dark Army: Uprising (RealRTCW Steam Workshop, the TDA folder) in VR
rem (falls back to the monitor without a headset).
call "%~dp0game\find_tda.cmd" || exit /b 1
call "%~dp0RealRTCW VR.bat" +set fs_game TDA %*
