@echo off
rem Single player co-op: the Cursed Sands campaign with friends, single player cutscenes and controls.
call "%~dp0RealRTCW VR.bat" +set fs_game EE +set g_spCoop 1 %*
