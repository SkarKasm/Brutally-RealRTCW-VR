@echo off
rem Single player co-op on the monitor: the RealRTCW campaign with friends.
call "%~dp0RealRTCW VR.bat" +set g_spCoop 1 +set vr_enable 0 %*
