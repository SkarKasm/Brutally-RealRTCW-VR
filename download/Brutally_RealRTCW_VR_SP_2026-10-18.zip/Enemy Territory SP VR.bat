@echo off
rem RealRTCW-VR: RealRTCW's Wolfenstein: Enemy Territory Single-Player (the ET folder) in VR
rem (falls back to the monitor without a headset).
call "%~dp0RealRTCW VR.bat" +set fs_game ET %*
