@echo off
rem RealRTCW-VR: RealRTCW's Wolfenstein: Enemy Territory Single-Player on the monitor only (a headset is ignored).
call "%~dp0RealRTCW VR.bat" +set fs_game ET +set vr_enable 0 %*
