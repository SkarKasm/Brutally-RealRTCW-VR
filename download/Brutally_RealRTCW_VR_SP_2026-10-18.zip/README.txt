RealRTCW-VR (single player)
===========================

Brutally RealRTCW VR is free and always will be. If you want to say thanks, you can buy
me a coffee here:
https://buymeacoffee.com/mrskarkasm

RealRTCW's single player campaign with full VR support: 6DOF head and hands, guns held in
your hands, manual reloading, see-through scopes, a physical knife and grenades, a full
body, ragdolls you can pick up and throw, a world-space menu with a laser pointer.
It also plays on the monitor without a headset.

For co-op, use the separate RealRTCW-VR-Coop package.


What's new (October 8 update)
-----------------------------
Fixes
- The launchers start again for everyone: they find RealRTCW from the folder you unzipped into
  (a bug in game\find_realrtcw.cmd closed them instantly when Steam wasn't in its default place).
- Ragdolls no longer spin or fly around: bodies settle down, can't be flung at crazy speeds,
  heads don't spin round, and bodies fall at real-world gravity
  (console: vr_ragdollGravity, default 400, the old value 800).
- Thrown bodies (flat body pickup) go a medium distance: enough to throw a soldier off a castle wall.

Gore
- Head shots on any soldier, alive or dead: bullet holes in the head, or sometimes the jaw shot
  away (a wound on the face itself), on every head model with its own textures.
- Head shots land on the head: the gore follows the bullet's path through the head, so a shot
  to the head no longer bleeds from the chest or tears an arm off. The head hit box is a little
  bigger too.
- Explosions close by tear bodies open: exposed ribs and guts, and a skinned head.
- Belly stabs show the guts on the front of the belly, following the body as it falls.
- Bloodier stumps that keep pumping blood for longer. Cut-off heads, and the bodies they came
  off, show a clean cut through the neck instead of an empty hole.
- New GORE & EXTRAS option "Original gibbing" (Off by default): explosions no longer burst
  soldiers into the game's stock gibs, so the mod's dismemberment takes them apart instead.

Weapons
- Dual wielding: a pistol or SMG in each hand (Luger, silenced Luger, Colt, TT-33, revolver,
  HDM, MP40, Thompson, Sten, PPSh, MP34). The guns are not mirrored: the left one is the real
  gun, ejecting to the right. Each gun has its own magazine.
  VR: double press the left grip to draw (or put away) the second gun; each trigger fires its
  own gun, and with both held they take turns. X drops the left gun's magazine, A the right
  one's; hold a hand down at your hip to reload that gun.
  Monitor: bind a key to "dualwield" (console: bind g dualwield); the two guns fire in turn.
- Shotgun blasts to the belly at close range rip the guts out.
- Monitor, experimental and off by default: aim down the sights. Type cg_flatADS 1 in the
  console and the zoom (alt fire) brings the gun up to your eye instead. Only the Lugers,
  Colt, MP40, Thompson, Sten, PPSh and MP34 for now; other guns keep the plain zoom.

Controls (VR)
- The RTCWQuest button layout (see VR controls below).
- Weapon wheel: hold the right grip, move your right hand towards a gun (or tilt the right
  stick) and let go. The gun you point at gets a highlight box and a buzz. A tap of the
  grip still reloads.
- Ladders: walk into them and look up or down to climb, like the flat game.
- Doors, buttons and levers: touch them with either hand to use them, or press use while
  looking at them.
- Knife: slash by swinging it; the trigger throws one (you keep your last knife).
- Cutscenes play on a big flat screen in front of you instead of moving the world around
  your head (console: vr_flatCutscenes 0 for the old way).
- VR: the game window on your monitor shows what your left eye sees, filling the whole window
  with no black bars, so you can record it (console: vr_mirrorFit 1 shows the whole eye
  image with bars instead, vr_mirror 2 shows the HUD layer, 0 turns it off).
- Other controllers: every VR button can be moved in game\main\vr_controls.cfg (the file
  explains each action and button).

Your body
- VR: every hand is drawn the same, life size, on every gun and free. Rifles that never
  showed a trigger hand (Kar98, Mosin, G43, Garand, MP44, Sten, MP34, Ithaca...) now have one
  holding the wrist of the stock. A bolt action's bolt stays shut after a shot until you work it.
- VR: your arms are the flat game's HD first person arms, with a wrist and an elbow that bend
  like a real arm (two-bone IK) up to BJ's shoulders, so you see one whole HD arm. A magazine
  in your hand turns with it and lines up with the gun as it gets close to the well. The 3D
  sky is drawn at infinity, so it no longer looks like a miniature in front of you. His idle
  animations are frozen so they don't pull the body around. Every gun is drawn at the size that makes its hand a real hand's size, so both
  hands always match and the guns come out close to their real lengths. Guns sit fixed in the hand with the finger on
  the trigger. Holding a rifle or SMG with both hands puts the support arm where it sits on
  the monitor. His uniform switches per map (camo on forest maps, white on
  snow maps). VR OPTIONS, Weapon size: Realistic (default), Larger or Smaller.
- BJ is a captain now: captain's bars instead of the private's chevron and a redrawn Rangers
  patch, on his body, in cutscenes and in VR.
- Monitor: look down to see your own body and legs, like Dying Light: the body stays upright
  under you and sits a little behind the camera (console: cg_flatLegs 0 turns it off,
  cg_flatLegsBack moves it back or forward, default 6).


What you need
-------------
- Return to Castle Wolfenstein (Steam)
- RealRTCW (Steam)
- For VR: a PC VR headset with SteamVR (or another OpenXR runtime) running.
  Quest: connect with Steam Link, Air Link, Virtual Desktop or a Link cable first.

Unzip into your RealRTCW folder (normally ...\steamapps\common\RealRTCW). Nothing of
RealRTCW's own is changed. Settings and saves are kept in the "game" folder.

The launchers find RealRTCW through Steam. If they can't, edit game\find_realrtcw.cmd
and set RRTCW to the RealRTCW folder (normally ...\steamapps\common\RealRTCW).


Launchers
---------
  RealRTCW VR.bat          the campaign in VR (falls back to the monitor without a headset)
  RealRTCW (no VR).bat     the campaign on the monitor
  Cursed Sands SP VR.bat       the Cursed Sands campaign in VR (needs RealRTCW's Cursed Sands, the EE folder)
  Cursed Sands SP (no VR).bat  the Cursed Sands campaign on the monitor
                               (Cursed Sands keeps its own settings, so set your VR OPTIONS there once)
  Enemy Territory SP VR.bat       RealRTCW's Wolfenstein: Enemy Territory Single-Player in VR (needs its ET folder)
  Enemy Territory SP (no VR).bat  Enemy Territory Single-Player on the monitor


Options
-------
Main menu or pause menu, VR OPTIONS: reloading, aim, turning, comfort, weapon size, height offset and the rest.

Main menu, pause menu (or VR OPTIONS), GORE & EXTRAS: everything here is optional, VR or not.
  Extra gore                 master switch for all the gory ones
  Body pickup (flat)         without a headset: hold USE on a body, attack throws it
  Grab assist                how far your hand reaches for things
  Can grab (VR)              a buzz / a hand sign when your hand is on something
  Shot reactions             enemies flinch, bodies are knocked about
  Bullet wounds              wounds where shots hit
  Throat cuts and guts       knife kills from behind cut the throat, low stabs open the belly
  Pick up and throw props    chairs, bottles, lamps...; thrown ones stun / hurt / break
  Knife takes heads (dead)   cut a dead body's neck; the head can be picked up and thrown
  Thrown heads               soldiers who see one land run, or drop their guns and give up
  Dismemberment (dead)       explosions (and heavy hits) take limbs off the dead
  Original gibbing           Off: explosions leave bodies whole for the gore above


VR controls (RTCWQuest layout)
------------------------------
Left stick           move (click: kick)
Right stick          left/right turn (snap or smooth), up jump, down crouch (hold)
Right stick click    use (doors, levers, where you look). Or touch doors, buttons and levers with a hand.
Right trigger        fire (knife: throw it; slash by swinging the knife)
Left trigger         sprint (with two guns: fires the left gun, and the left grip sprints)
Right grip (hold)    weapon wheel: move the right hand towards a weapon (or tilt the right
                     stick), then let go of the grip or pull the trigger
Left grip            hold the gun with both hands (close it where the flat game's support
                     hand holds it, e.g. the MP40's magazine well), take a magazine from
                     your chest and push it into the gun, grab bodies, props and heads
Left trigger         on the slide / bolt / pump handle: grab it and pull it back
Right grip (tap)     on a gun held with both hands: the right hand lets go and the left
                     hand holds it alone. Then the right trigger on the bolt / slide grabs
                     it and pulls it back, and a right grip press back on the gun takes it
Left grip (double)   a second pistol / SMG, or back to one
A                    drop the magazine (manual reloading) / reload; two guns: the right gun's
X                    drop the magazine; two guns: the left gun's
B                    jump         Y   notebook
Right grip + A       toggle HUD
Right grip + X       use item       Right grip + B   next item
Two guns             hold a hand down at your hip to reload that gun.
Ladders              walk into them and look up or down to climb, like the flat game.
Other controllers    edit game\main\vr_controls.cfg to move any of the above.
Menu button          game menu; in menus point with either controller and pull the trigger
Any button during cutscenes and videos skips them.
What's new (October 17 update)
------------------------------
Built from the GitHub source (main, commit 57f9dbb), with the engine and renderer that
match it, so dismemberment, wounds and dual wielding all come from one build.

Survival
- Human enemies keep coming after wave 1. An enemy who had been shot down, had an arm shot
  off or had given up used to come back in the next wave unarmed and frozen in place (and,
  if they had surrendered, still with their hands up), so the waves stalled. They now come
  back armed and fighting.
- Killing an enemy who surrendered no longer breaks the waves.
- Enemies who drop their gun (shot down, crippled, surrendered) no longer leave a weapon on
  the ground to pick up in Survival.
- HUD: ENEMIES LEFT in the wave at the top of the screen, and with 3 or fewer left a small
  compass under it with an arrow (and the distance) to each of them, ahead is up.
- A rare crash when an enemy died with no attacker is fixed.

Gore
- Limbs come off the body instead of a second copy of the whole body flying off (the last
  full package had an older renderer that didn't know how to cut a limb off the body).
- Elite guards and the other characters lose their limbs too: the limb really comes off,
  so no stump is drawn over a limb that stays on.
- Bullet holes are smaller (about the size of the round) and sit where the shot went in.

Enemy Territory SP
- Starts and loads levels (the UI's menu memory was too small for ET's menus).

Install: unzip into your RealRTCW folder. It only has the mod's own files ("game" folder and
the launchers); RealRTCW's Main folder is not touched. Back up your game folder first.
